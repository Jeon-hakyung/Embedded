#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    if (argc != 3) {
        fprintf(stderr, "usage: %s <mode> <pathname>\n", argv[0]);
        exit(1);
    }

	int newmode = (int) strtol(argv[1], (char **) NULL, 8);
	if (/* 대상 파일의 접근권한을 newmode로 변경 */ == -1) {
		perror(argv[2]);
		exit(1);
	}

	exit(0);
}
