#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    if (argc != 2) {
        fprintf(stderr, "usage: %s <pathname>\n", argv[0]);
        exit(1);
    }

    struct stat statbuf;
    /* 파일의 상태 정보 읽기 */

    // 파일의 종류 얻기
    if (/* 심벌릭링크인가? */)
        printf("%s: symbolic link\n", argv[1]);

    else if (/* 디렉터리인가? */)
        printf("%s: directory\n", argv[1]);

    else if (/* 일반파일인가? */))
        printf("%s: regular file\n", argv[1]);

    return 0;
}
